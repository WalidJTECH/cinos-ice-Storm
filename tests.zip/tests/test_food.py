import unittest
from api.food import Food

class TestFood(unittest.TestCase):
    def setUp(self):
        self.food = Food('Hotdog')

    def test_add_topping(self):
        self.food.add_topping('Ketchup')
        self.assertAlmostEqual(self.food.get_price(), 2.3)

    def test_invalid_topping(self):
        with self.assertRaises(ValueError):
            self.food.add_topping('Invalid')

if __name__ == '__main__':
    unittest.main()