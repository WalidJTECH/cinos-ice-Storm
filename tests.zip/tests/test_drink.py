import unittest
from api.drink import Drink

class TestDrink(unittest.TestCase):
    def setUp(self):
        self.drink = Drink()

    def test_add_base(self):
        self.drink.add_base('water')
        self.assertEqual(self.drink.get_base(), 'water')

    def test_invalid_base(self):
        with self.assertRaises(ValueError):
            self.drink.add_base('invalid')

    def test_add_flavor(self):
        self.drink.add_flavor('lemon')
        self.assertIn('lemon', self.drink.get_flavors())

if __name__ == '__main__':
    unittest.main()