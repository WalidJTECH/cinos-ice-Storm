from typing import Dict

class Food:
    """Class to represent a food item."""
    _VALID_FOOD_ITEMS = {
        'Hotdog': 2.3,
        'Corndog': 2.0
    }
    _VALID_TOPPINGS = {
        'Ketchup': 0.0,
        'Mustard': 0.0
    }

    def __init__(self, food_item: str):
        if food_item not in self._VALID_FOOD_ITEMS:
            raise ValueError("Invalid food item.")
        self._food_item = food_item
        self._toppings = {}

    def add_topping(self, topping: str):
        if topping not in self._VALID_TOPPINGS:
            raise ValueError("Invalid topping.")
        self._toppings[topping] = self._VALID_TOPPINGS[topping]

    def get_price(self):
        return self._VALID_FOOD_ITEMS[self._food_item] + sum(self._toppings.values())