from typing import List, Optional

class Drink:
    """Class to represent a drink with a single base and multiple flavors."""
    _VALID_BASES = ['water', 'sbrite', 'pokeacola', 'Mr. Salt', 'hill fog', 'leaf wine']
    _VALID_FLAVORS = ['lemon', 'cherry', 'strawberry', 'mint', 'blueberry', 'lime']

    def __init__(self) -> None:
        self._base: Optional[str] = None
        self._flavors: set[str] = set()

    def add_base(self, base: str) -> None:
        if self._base:
            raise ValueError("Base already set.")
        if base not in self._VALID_BASES:
            raise ValueError("Invalid base.")
        self._base = base

    def add_flavor(self, flavor: str) -> None:
        if flavor not in self._VALID_FLAVORS:
            raise ValueError("Invalid flavor.")
        self._flavors.add(flavor)

    def get_base(self):
        return self._base

    def get_flavors(self):
        return sorted(self._flavors)