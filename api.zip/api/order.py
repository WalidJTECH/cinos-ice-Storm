from typing import List, Union
from .drink import Drink
from .food import Food
from .ice_storm import IceStorm

class Order:
    """Class to represent an order."""
    def __init__(self):
        self._items: List[Union[Drink, Food, IceStorm]] = []

    def add_item(self, item):
        self._items.append(item)

    def get_total(self):
        return sum(item.get_total() for item in self._items if hasattr(item, 'get_total'))